PlazCode 1.24.12 — Memory, Notion and Blender fixes + new UltraGUI

Fixes memory notes that could not be pasted into, Notion startup freezes, plans that stopped without starting, false "Not connected" bars and Blender commands failing while busy. UltraGUI is replaced with the new GUI skill pack, and the desktop app gets an automatic-updates switch.
