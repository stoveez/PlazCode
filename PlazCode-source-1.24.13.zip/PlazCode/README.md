PlazCode 1.24.13 — Skills, connection and Blender fixes

The approved test build 6: faster startup, reliable connection status, improved Skills controls, a one-click Save as skill card, and the user-tested Blender screenshot and dashboard fixes.
