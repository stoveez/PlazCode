PlazCode 1.24.5 — DeepSeek Ultracode and smoother Notion startup

A focused DeepSeek thinking mode, less repeated work and more reliable Notion startup.
