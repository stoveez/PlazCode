PlazCode 1.24.6 — Responsive commands, stable checklists and skill imports

Recover from stuck command waits, continue safely after Stop, and import your own skills.
