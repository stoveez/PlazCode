const {chromium,firefox}=require('playwright'),fs=require('fs'),assert=require('node:assert/strict');
const html=fs.readFileSync('agent/src/desktop.html','utf8');
const clean=html.replaceAll('__PLAZCODE_VERSION__','1.24.6').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,'');
const setup=html.slice(html.indexOf('  function Setupsettingssections('),html.indexOf('  function Go('));
const effort=html.slice(html.indexOf('  function Rendereffort('),html.indexOf('  function Rendersettings('));
const go=html.slice(html.indexOf('  function Go('),html.indexOf('  function ',html.indexOf('  function Go(')+20));
(async()=>{for(const [name,engine] of [['chromium',chromium],['firefox',firefox]]){
 const browser=await engine.launch({headless:true}),page=await browser.newPage();page.setDefaultTimeout(15000);
 try{
 await page.route('http://localhost:34567/**',route=>route.fulfill({contentType:'text/html',body:clean}));
 await page.goto('http://localhost:34567/');await page.emulateMedia({reducedMotion:'reduce'});
 await page.evaluate(()=>{window.Byid=id=>document.getElementById(id);window.Toarray=x=>Array.from(x);window.Refreshupdates=()=>{};window.Rendertools=window.Measuredescriptions=window.Renderlogs=window.Loadcatalog=()=>{};window.Templateui=window.Skillsui={refresh(){}};window.Modelui=window.Uibuilder={pause(){},startPolling(){}};window.Explorerui={pause(){},refresh(){}};window.Follow=false;});
 await page.addScriptTag({content:setup+effort+go});await page.addScriptTag({path:'core/version.js'});await page.addScriptTag({path:'core/skills-ui.js'});
 await page.evaluate(()=>{for(const id of ['sidebarVersion','titleVersion','settingsVersion','updateInstalled','updateLatest'])PlazCodeVersion.render(Byid(id),'1.24.6',{latest:'1.24.6',checked_at:Date.now()},id==='titleVersion'?'PlazCode ':'');});
 for(const id of ['sidebarVersion','titleVersion','settingsVersion','updateInstalled','updateLatest'])assert.match(await page.locator('#'+id).textContent(),/v1\.24\.06/);
 await page.evaluate(()=>{window.memoryRefreshes=0;Setupsettingssections(()=>memoryRefreshes++);Go('settings');});
 const sections=page.locator('#page-settings details.settings-section');assert(await sections.count()>5);
 for(let i=0;i<await sections.count();i++){assert(await sections.nth(i).locator('summary h3').isVisible());assert(await sections.nth(i).locator('summary p').isVisible());assert.equal(await sections.nth(i).getAttribute('open'),null);}
 const first=sections.first();await first.locator('summary').click();assert(await first.locator('.settings-section-body').isVisible());await first.locator('summary').click();assert(await first.locator('.settings-section-body').isHidden());
 await first.locator('summary').focus();await page.keyboard.press('Enter');assert(await first.locator('.settings-section-body').isVisible());
 await page.evaluate(()=>{const input=document.querySelector('#page-settings select');input.value=input.options[input.options.length-1].value;window.preservedValue=input.value;input.addEventListener('change',()=>window.retainedListener=true);window.savedInput=input;document.querySelectorAll('#page-settings details').forEach(d=>d.open=true);});
 for(const [width,height] of [[1280,720],[1140,800],[700,500]]){
  await page.setViewportSize({width,height});
  const geometry=await page.locator('.content').evaluate(n=>{n.scrollTop=n.scrollHeight;const r=n.getBoundingClientRect();return {bottom:r.bottom,client:n.clientHeight,height:n.scrollHeight,top:n.scrollTop,overflow:getComputedStyle(n).overflowY};});
  const gap=await page.evaluate(()=>document.querySelector('[data-settings-section=debugReport]').getBoundingClientRect().top-document.querySelector('#page-settings>.settingsgrid').getBoundingClientRect().bottom);assert(gap>=17.99,`${name}: Debug report stays separated from Desktop settings at ${width}px`);
  if(width>760){const alignment=await page.evaluate(()=>(()=>{const a=Byid('titleVersion').getBoundingClientRect(),b=Byid('titleEffort').getBoundingClientRect();return{version:{x:a.x,y:a.y,height:a.height},effort:{x:b.x,y:b.y}};})());assert(Math.abs(alignment.version.x-alignment.effort.x)<.01);assert(alignment.effort.y>=alignment.version.y+alignment.version.height);}
  assert(geometry.bottom<=height+1,`${name}: viewport bottom reachable at ${width}×${height}`);assert.equal(geometry.overflow,'scroll');assert(geometry.height>geometry.client);assert(Math.abs(geometry.top+geometry.client-geometry.height)<2);
  const nav=await page.locator('.nav').evaluate(n=>{n.scrollTop=n.scrollHeight;const r=n.getBoundingClientRect(),s=n.querySelector('[data-page=settings]').getBoundingClientRect();return {bottom:r.bottom,settings:s.bottom,top:r.top,settingsTop:s.top};});
  assert(nav.bottom<=height);assert(nav.settings<=nav.bottom+1);assert(nav.settingsTop>=nav.top-1);
 }
 await page.evaluate(()=>{const input=savedInput;input.closest('details').open=false;input.closest('details').open=true;input.dispatchEvent(new Event('change'));});assert.equal(await page.evaluate(()=>savedInput.value),await page.evaluate(()=>preservedValue));assert(await page.evaluate(()=>retainedListener));
 await page.evaluate(()=>Go('updates'));assert(await page.locator('#page-updates').isVisible());assert.equal(await page.locator('.navbtn.active').getAttribute('data-page'),'updates');
 for(const level of ['default','low','mid','high','max','ultracode']){
  await page.evaluate(level=>Rendereffort(level),level);
  const colors=await page.locator('#titleEffort').evaluate(n=>[getComputedStyle(n).color,getComputedStyle(n.querySelector('span')).color]);assert.equal(colors[0],colors[1]);
 }
 assert((await page.locator('#titleEffort').textContent()).includes('Effort: Ultracode'));assert(!(await page.locator('#titleEffort').textContent()).includes('Beta'));assert.equal(await page.locator('option[value=ultracode]').last().textContent(),'Ultracode (Beta)');
 await page.evaluate(()=>{window.skillRecords=[];window.skillSaves=0;window.sentSkillTasks=0;Skillsui=PlazCodeSkillsUI.mount(Byid('skillsWorkspace'),async r=>{if(r.action==='list')return{ok:true,skills:skillRecords};if(r.action==='save'){skillSaves++;const skill={...r.skill,revision:1};skillRecords.push(skill);return{ok:true,skill};}if(r.action==='export')return{ok:true,skill:{...skillRecords.find(s=>s.id===r.id),scope:''}};throw Error(r.action);},async()=>{sentSkillTasks++;},()=>({}),async()=>{},async()=>({tasks:[]}));Go('skills');});
 for(const [width,height] of [[1280,800],[700,600]]){
  await page.setViewportSize({width,height});const host=page.locator('#skillsWorkspace');assert(await host.locator('[data-sk=steps]').isVisible());assert(await host.locator('[data-sk=scope]').isVisible());assert(await host.locator('[data-sk=save]').isVisible());assert(await host.locator('[data-sk=open-import]').isVisible());assert(await host.locator('[data-sk=export]').isVisible());
  for(const field of ['title','description','domain','pitfalls','verification','goal','tasks'])assert(await host.locator('[data-sk='+field+']').isHidden(),`${name}: ${field} is not part of the beginner editor`);
  const bounds=await host.locator('[data-sk=steps]').evaluate(n=>{const r=n.getBoundingClientRect();return{x:r.x,right:r.right,width:r.width};});assert(bounds.width>150&&bounds.x>=0&&bounds.right<=width);
 }
 await page.locator('[data-sk=steps]').fill('Match the project UI style and check mobile layouts.');await page.locator('[data-sk=scope]').fill('project:Game A');await page.locator('[data-sk=save]').click();await page.waitForFunction(()=>skillSaves===1&&document.querySelector('[data-sk=status]').textContent.startsWith('Saved.'));
 assert.equal(await page.evaluate(()=>sentSkillTasks),0);assert(await page.evaluate(()=>skillRecords[0].enabled&&!skillRecords[0].confirmed&&skillRecords[0].scope==='project:Game A'));assert(await page.locator('[data-sk=title]').isHidden());
 const download=page.waitForEvent('download');await page.locator('[data-sk=export]').click();const file=await download;const exported=JSON.parse(fs.readFileSync(await file.path(),'utf8'));assert.equal(exported.steps.join(''),'Match the project UI style and check mobile layouts.');assert.equal(exported.scope,'');
 await page.locator('[data-sk=open-import]').click();assert(await page.locator('[data-sk=import-text]').isVisible());await page.locator('[data-sk=import-text]').fill('Read existing code and preserve working behavior.');await page.locator('[data-sk=import]').click();await page.waitForFunction(()=>skillSaves===2&&document.querySelector('[data-sk=status]').textContent.startsWith('Skill imported'));assert(await page.evaluate(()=>skillRecords[1].confirmed===false&&skillRecords[1].enabled===undefined));
 if(process.env.PLAZCODE_SKILLS_SCREENSHOT){await page.locator('[data-sk=new]').click();await page.setViewportSize({width:1280,height:900});await page.screenshot({path:process.env.PLAZCODE_SKILLS_SCREENSHOT,fullPage:true});}
 console.log(`${name}: one-box Skills Save, optional scope, real JSON download, unchanged text import, collapsed advanced fields and narrow layout passed.`);
 console.log(`${name}: bounded workspace scrolling at three sizes, reachable sidebar bottom, expandable Settings preserving values/listeners, Updates navigation, and whole effort label color passed.`);}finally{await browser.close();}
}})().catch(e=>{console.error(e);process.exitCode=1;});
