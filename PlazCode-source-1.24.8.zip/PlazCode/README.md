PlazCode 1.24.8 — Quick replies, clear tasks and Notion fixes

Small requests stay brief, checklists follow your goals, and Notion handles results and connection status more reliably.
