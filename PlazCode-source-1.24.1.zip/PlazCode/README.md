PlazCode 1.24.1 — Reliable results and a browsable Skills page

Keep repeated tool results flowing, wait for complete ChatGPT replies, and browse, inspect or add adaptable project skills.
