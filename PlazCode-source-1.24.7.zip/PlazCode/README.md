PlazCode 1.24.7 — Name your skills and a clearer Skills layout

Give your skills a name, or let PlazCode name them for you. Learning and library options now have clearer spacing.
