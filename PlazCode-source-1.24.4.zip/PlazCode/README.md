PlazCode 1.24.4 — Faster Ultracode and more reliable chat

Less repeated work, easier Settings and fixes for Notion and screenshots.
