PlazCode 1.24.14 — Co-Work cleanup, Claude replies and Studio startup

Sent Co-Work requests clear immediately, completed Claude replies are read reliably, and Studio connection starts automatically with stronger Windows launcher discovery.
