#!/usr/bin/env python3
"""ultragui.py - UltraGUI: UltraCode for Roblox interfaces, as a prompt plus skills.

Same idea as ultracode.py. ZeroScript-Free only gives the model text, so UltraGUI is
text too: the Custom prompt box, plus named skills the model applies when they match.

  PROMPT   the working mode for interface work: search, plan the screens, build one
           screen or component at a time, measure its layout, and run a check-and-fix cycle.
  SKILLS   the Check-UI cartoon standard, the GUI rules, library packs, reference sources,
           the Toolbox rules, the reference library, and the verification checks.

What the model can and cannot reach from ZeroScript:
  fetch_roblox_doc            Roblox docs pages only (create.roblox.com, developer.roblox.com).
  search_creator_store        Studio's Toolbox search, through the Roblox server.
  insert_from_creator_store   Studio's Toolbox insert (search_asset / insert_asset on older builds).
  Local files in references/  NOT readable by these tools. They reach the model only through
                              --full (which pastes the Check-UI text into the prompt) or by
                              the user pasting them.

Syntax check (run by the user, not by the model): check_gui_syntax.py checks GUI Luau against
Roblox's API dump. Paste a generated script into a .lua file and run:
  python check_gui_syntax.py API-Dump.json screen.lua

Usage:
  python ultragui.py                        print the compact prompt (paste into Custom prompt)
  python ultragui.py --full                 print the prompt with the full Check-UI text added
  python ultragui.py --out prompt.txt       write it to a file instead (add --full to include it)
  python ultragui.py --list                 list the skills
  python ultragui.py --skill check-ui-standard   print one skill only

To change UltraGUI, edit PROMPT or SKILLS below. Nothing else is needed.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
CHECK_UI_FULL = HERE / "references" / "check-ui" / "SKILL.md"

# ============================================================================
#  PROMPT  (the working mode, always on when UltraGUI is on)
# ============================================================================

PROMPT = """UltraGUI mode is on. Work this way for every Roblox interface task: menus, HUDs,
shop screens, buttons, inventories, settings, and anything the player sees.

Take the time you need. Do not rush, and do not skip a check to finish sooner. Long work is
fine: split it into screens, and finish one before you start the next.

Style. If the user asks for a cartoon, simulator or tycoon look, or names Check-UI, follow
the check-ui-standard skill exactly. Build a screen on one of its five archetypes (Shop,
Codes, Rebirth, Settings, Daily Rewards) when one fits.

Order of work. Follow this order every time:
  1. Plan the screens. For each screen, write its purpose, its elements, and its states
     (default, hovered, pressed, disabled, loading, empty). Note the style, the library pack
     (gui-packs), and which Roblox APIs you are not sure of.
  2. Search, then gather. Run the searches in the SEARCH section below for every screen,
     before you build it. Use the reference-library, gui-references and gui-toolbox skills
     for what you find.
  3. Build one item at a time. An item is one screen or one component. For each item: build
     it, measure its layout numbers, check it against gui-layout, check-ui-standard and
     check-cycle, and fix the cause if a check fails. Repeat up to three cycles. If it still
     fails after three, stop on that item, report it as stuck with the reason, and go on only
     with items that do not depend on it.
  4. Verify each screen with gui-verify: measured positions and sizes at three screen sizes,
     then a play test that a human must run. Before that, run the gui-syntax checklist on
     every GUI script. Mark an item done only after its checks pass.
  5. Report with the report-what-you-verified skill.

You cannot run Studio from here. Every check is by reading or by the numbers the code
computes. Say plainly what was checked that way, and what only a human can see in play.

Keep each tool call short. A call that runs too long is cut off: execute_luau after about
20 seconds, other tools after about 2 minutes. Split a long check into several calls. If the
whole job will not fit in one reply, stop at an item boundary, say which items are done and
what is next, and wait for the user to say go on.

SEARCH. Searching is part of every interface task, not an option.
Before you build a screen, search in this order and write down each query and what it returned:
  a. Reference library: the check-ui-standard and reference-library skills. Use them first.
  b. Roblox docs: fetch_roblox_doc on the UI classes you plan to use (ScreenGui, Frame,
     TextButton, UIListLayout, UIPadding, UICorner, UIStroke, UIScale, UITextSizeConstraint),
     and on any library pack you chose. Quote what each page says.
  c. Studio Toolbox: search_creator_store with specific terms (see gui-toolbox). Record the top
     results, their creators, and why you chose or rejected each one.
  d. The open web: YouTube, GitHub, Discord, TikTok and forum examples. Use a web search tool
     only if this chat has one turned on. Search with specific terms, such as "roblox shop ui
     layout phone". Note each source, its date, and what you took from it. Prefer official docs
     and well-known open-source repos over posts. Do not repeat a search that already returned
     what you needed.
  e. If this chat has no web search tool, or a search fails, say so in the report. Then ask the
     user to paste the links or text for the screens you could not search. Do not invent search
     results or quote a page you did not read.
Searches are for ideas and facts. Anything you rely on for code must still pass the check-cycle
and gui-verify skills. A result from a video or a post is an opinion until the Roblox docs agree.

Apply a skill whenever its "Use when" line matches the item. You may use more than one."""


# ============================================================================
#  SKILLS  (edit, add or remove skills here)
# ============================================================================

SKILLS = [
    {
        "name": "gui-syntax",
        "use_when": "every GUI script, before it is marked done. Apply it to any code that creates or changes "
                    "ScreenGui, Frame, TextButton, TextLabel, ImageLabel, UI modifiers or gradients.",
        "body": """Write GUI code that Roblox accepts. These rules come from Roblox's own API dump.

Create and set up objects:
- Create with Instance.new("ClassName"). Set the properties, then set Parent last.
- Text lives on TextButton and TextLabel. ImageButton and ImageLabel have no Text or Font, so
  never set them on an image class.
- Click handlers: use Activated. It works for mouse, touch and gamepad. MouseButton1Click
  works for mouse and touch only.
- Enums are written in full and spelled exactly, such as Enum.Font.GothamBlack,
  Enum.ApplyStrokeMode.Border, Enum.ScaleType.Fit. A misspelt enum is an error.
- A ScreenGui made in a LocalScript goes under the player's PlayerGui:
  screen.Parent = player:WaitForChild("PlayerGui")
- Use task.wait and task.delay, never wait() or delay().

Value types:
- UDim2.new takes four numbers: scaleX, offsetX, scaleY, offsetY.
- UDim.new takes two numbers. Color3.fromRGB takes three values from 0 to 255. Color3.new takes
  three values from 0 to 1. Vector2.new takes two numbers.
- Transparency is a number from 0 to 1.
- ColorSequence and NumberSequence keypoints run from time 0 to time 1, in increasing order, and must
  start at 0 and end at 1.
- Image properties take "rbxassetid://<id>". Icons use ScaleType.Fit (never stretched). Textures
  that repeat use ScaleType.Tile with a TileSize.

Text and shape:
- Fit text with TextScaled = true, plus a UITextSizeConstraint with MinTextSize and MaxTextSize.
- Rounded corners: UICorner.CornerRadius = UDim.new(0, pixels).
- Outlines: UIStroke with ApplyStrokeMode = Enum.ApplyStrokeMode.Border, and a Thickness in pixels.
- UIGradient.Color is a ColorSequence. UIGradient.Transparency is a NumberSequence.

Check the script before it is done. The user can run check_gui_syntax.py on it. That checks:
- every Instance.new class name is real and creatable
- every property set on an object exists on that class and takes a matching type
- every :Connect event exists on that class
- every Enum.Type.Item exists
- argument counts for UDim2, UDim, Color3, Vector2 and keypoints are right

Limits of that check: it tracks only variables made with Instance.new in the same file. It does not
catch undefined variables or scope errors, so read those by hand. Passing it does not prove the code
runs. Say so in the report.

Example that follows every rule above. It passes check_gui_syntax.py with 0 failures. It is a
LocalScript:
```lua
<<EXAMPLE>>
```""",
    },
    {
        "name": "check-ui-standard",
        "use_when": "building a cartoon, simulator or tycoon interface, or when the user names Check-UI. "
                    "Full recipes: references/check-ui/SKILL.md (or --full).",
        "body": """Core rules. Every one is non-negotiable.
1. Font: every text object uses Enum.Font.GothamBlack, with a black UIStroke 2.0 to 3.5 px,
   scaled to the text size.
2. Window canvas: solid Color3.fromRGB(59, 88, 102) (#3B5866), BackgroundTransparency 0, with
   a 4 px UICorner and an outer UIStroke of 3.5 px in #181E22. Never semi-transparent.
3. Close button: a 38 x 38 px square. Dark burgundy bevel #730010 under the face (the reference
   code uses 4 px). Face gradient #FF7DAF to #FF1428 at 90 degrees. Inner pastel stroke #FFD2EB,
   1.2 px. White GothamBlack "X" with a black stroke. A child UIScale.
4. Header: 60 px tall. It ends with a two-line divider: a 3 px dark thematic bar, then a 3 px
   solid black bar.
5. Checkerboard: rbxassetid://385956923 at full height. Vertical UIGradient transparency
   1 -> 0.82 -> 0.35 -> 0.10, so there are no hard edges.
6. Icons: ScaleType = Enum.ScaleType.Fit. Never stretched.
7. Responsive: factor = min(ViewportSize.X / 1050, ViewportSize.Y / 620), clamped to 0.52 to 1.18,
   applied to a UIScale on each window and HUD.
8. Centre anchor: every interactive element has AnchorPoint (0.5, 0.5) and a child UIScale, so
   hover and press scale from the centre.
9. Five archetypes: Shop, Codes, Rebirth, Settings, Daily Rewards. Each has its own header gradient:
   Shop #FF1496 -> #E10019; Codes #00CDFF -> #0082F5; Settings #FFFFFF -> #D7DEE8; Rebirth
   #A000FF -> #6000C8; Daily Rewards #98FF00 -> #50D000. Every header is 60 px with the same divider.
10. Iconless buttons (Throw, Action, Jump, Redeem, Confirm, Ok): sharp 90-degree corners with NO
   UICorner. A 3 px #0C141A border. A 90-degree gradient. A black checkerboard overlay fading
   0.91 -> 0.62. Three inner highlight frames inset 2, 4 and 6 px, with white 1 px strokes at
   transparency 0.25, 0.45 and 0.80. A centred white GothamBlack label with a 3 px #11171A stroke
   and a 1 px upward optical lift.
11. Button states: Claim/Buy lime #B4FF19 -> #69E100, bevel #0F780F. Claimed silver #D8DEE4 ->
   #94A0B0, bevel #485260. Locked crimson #FF2050 -> #D00020, bevel #700010. Skip amber #FFD000 ->
   #FF8C00, bevel #994C00. Music/feature hot pink #FF1480 -> #D40055, bevel #780A2D.
12. Every button has a 3 px dark bottom bevel.
13. Sunbursts rotate at 20 degrees per second, and only while their window is visible.

Palette (Color3 RGB): canvas 59,88,102; outline 24,30,34; card 26,44,52; card highlight 75,125,145;
requirements box 20,34,42; close bevel 115,0,16; close highlight 255,210,235.

Asset IDs in the reference: checkerboard 385956923; sunburst 130563114903838; cash 88694661500877;
player 77589096360120; Robux 132185731364109. Confirm each loads before you use it, and keep the IDs
in a Config module, not inside a service. The reference lists 6895079853 for both hover and click
sound. That looks like a copy error, so confirm the click sound ID.

Known gaps in the reference code: the responsive and animation samples use playerGui, playSound,
hoverSound, clickSound, RunService and TweenService without defining them. Define them before use.
The CheckUIIcons registry (1,022 icons under ReplicatedStorage.CheckUI) is not in this project. Do not
reference it unless the user adds it.

Checklist for every Check-UI screen: all text GothamBlack; canvas solid #3B5866; close button 38 x 38;
header divider two-tone; checkerboard with a four-point gradient; icons Fit; centre anchors on all
interactive elements; responsive factor clamped to 0.52 to 1.18; the screen is one of the five
archetypes; iconless buttons use the sharp-corner recipe.""",
    },
    {
        "name": "reference-library",
        "use_when": "any task that needs icon style, a Check-UI recipe, or a hat or icon example.",
        "body": """The reference files sit in references/ next to ultragui.py. The model can read them only if an
addon tool reads them, or the user pastes them, or the build used --full.
- references/check-ui/SKILL.md: the full Check-UI standard, 667 lines, with every recipe and code
  sample. Read it before building any cartoon or simulator screen. --full pastes it into the prompt.
- references/check-ui/Copy_And_Paste_Skill.txt: the short version of the same standard. The numbers match.
- references/vector-hats/: 494 icon files in 27 folders (Baseball Cap, Beanie, Beret, Top Hat, Wizard Hat,
  and more). Each hat comes as a PNG at 64 px and 256 px, and as an SVG, in a plain and an outline version.
  Use them as the reference for icon style, outline weight and silhouette. Use the 256 px PNG for large
  displays and the 64 px PNG for small ones. Icons are always ScaleType Fit.
- The hat bundle's terms are on the rhosgfx license page named in its License.url file. Read that before
  any of these images ship in a game. Do not assume they are free to use.
- references/gui-syntax/: example.lua, a GUI script that passes check_gui_syntax.py, plus test files.
- references/gui-verify/: the layout verifier (gui_rules.lua, verify_gui.client.lua) and its tests.
- The roblox-ai-skills upload was empty, so it is not in references/. Do not look for GUI examples there.""",
    },
    {
        "name": "check-cycle",
        "use_when": "every item, before it is marked done. This is the check step of the cycle.",
        "body": """Read the item's code against this list. Say pass or fail for each line.
- It parses: every function, if, for and do is closed, and no stray characters remain.
- Names exist: every require path, service name, and instance name the code depends on
  is spelled the same place it is defined.
- Remote arguments match at all three ends: the sender, the server handler and the receiver.
- The server validates every value that came from a client: type, range, ownership, then
  distance or cooldown. A button must never be the only thing that decides a purchase.
- Every tunable number, such as prices, sizes or timers, comes from a Config module.
- No wait(), spawn() or delay(). Use task.wait, task.spawn and task.delay.
- Every connection is kept or disconnected. Nothing rebuilds the whole screen every frame.
- Every Roblox API the item uses was looked up in this cycle, or is listed as unverified.
- A check that cannot find its target fails. "Not found" is a fail, not a pass.
If any line fails, fix it and run this list again.""",
    },
    {
        "name": "gui-layout",
        "use_when": "building or changing any ScreenGui, Frame, button, label, list, menu or HUD element.",
        "body": """Layout is numbers first. Decide the numbers, then check them.
- Position and size use UDim2 with a scale part and an offset part. A scale-only layout
  breaks on other screen sizes; an offset-only layout breaks on phones. Use both on purpose.
- Centred means measured. Anchor the element at (0.5, 0.5) and place it at (0.5, 0) so it
  lands in the middle. A 0.5 position with the default top-left anchor is off-centre by half
  its own size, and it looks almost right.
- Elements must never touch. Keep at least 8 pixels between siblings at the reference size.
  Overlap is a failure unless it is deliberate, and a deliberate overlap is stated in the plan.
- No frame draws a box around a single child. A container that only positions its child is
  transparent (BackgroundTransparency = 1). An opaque container within 6 pixels of its one
  child is the classic box-around-the-button defect.
- Use UIListLayout, UIGridLayout and UIPadding for repeated items, not hand-placed copies.
- Text uses TextScaled only with a TextSize cap (UITextSizeConstraint), so it stays readable
  on large and small screens.
- Give every interactive element a clear pressed and disabled look, not only a hover look.
  Phones have no hover.
- Respect the top bar and safe areas. Do not put a button under the Roblox top bar.
- Set ResetOnSpawn deliberately. If the HUD should survive respawn, say so in the plan.""",
    },
    {
        "name": "gui-packs",
        "use_when": "choosing how to build a screen: plain Roblox objects, or a library pack. Also when a "
                    "project already uses a library.",
        "body": """Pick one approach per project and keep it. Do not mix two libraries in one interface.
Default: plain Roblox objects (ScreenGui, Frame, TextButton, UIListLayout, UIPadding,
UICorner, UIStroke). Use this for menus and HUDs unless there is a clear reason not to.
Library packs confirmed to exist on GitHub:
- Fusion (github.com/dphfox/Fusion): a declarative state system. Good when a screen has many
  values that change together. Confirm the version you use and read its docs first.
- Rayfield (github.com/shlexware/Rayfield): a ready-made window, tabs and controls, usually
  loaded from a URL. Good for quick tools. Read its license before you use it.
- Roact (github.com/Roblox/roact): an older declarative library. Use it only if the project
  already uses it; do not start a new project on it without checking its current status.
Rules for any pack:
- Read its license file and its docs before you use it. Confirm its version.
- Never load a library from a URL at run time, such as loadstring(game:HttpGet(...)). That runs
  code you have not read, and it can change after you checked it. Instead, copy the library
  into src/ as a ModuleScript at a fixed version, read it, and let Rojo serve it.
- Say in the plan which pack you chose and why. If you chose plain Roblox objects, say so too.""",
    },
    {
        "name": "gui-references",
        "use_when": "looking for examples, layouts, design ideas or how other games solve an interface problem.",
        "body": """Know which sources you can reach, and what each one is good for.
- Reference library (see reference-library): check it first.
- Roblox docs (fetch_roblox_doc): the authority for how an API works. Use it for any claim about
  properties, events, or what a UI object does.
- Studio Toolbox (search_creator_store): ready-made interface pieces. See gui-toolbox.
- YouTube, TikTok, Discord, GitHub and forums: the model cannot search or open these from here. Ask
  the user to paste the link, or the text or code they want to share. Say what you need from it,
  such as "the layout of the shop screen" or "how they handle the close button on phones".
- Treat any pasted example as a reference for layout and feel, not as code to copy. Check its
  license first if it is code. Do not copy a whole screen; take the idea and build it with the
  rules in gui-layout and check-ui-standard.
- Video and social posts are opinions. Use them to find ideas, then check the idea against the
  Roblox docs before you rely on it.
- In the report, list every reference you used, by the link or name the user gave you, and say
  what you took from it.""",
    },
    {
        "name": "gui-toolbox",
        "use_when": "the user asks for good GUI pieces, or a screen needs a ready-made interface kit, "
                    "button style, icon set, or HUD template.",
        "body": """Search with search_creator_store. Good terms are specific: "shop UI template", "inventory
grid ui", "dark menu kit", "health bar ui", "settings menu ui". One word gives noise.
- Read each result's name, creator and type. Prefer assets from verified creators. Compare at
  least three results before choosing one, and say why you chose it.
- A GUI asset is mostly ScreenGui, Frame and TextLabel objects. Before you insert, look for
  Script and LocalScript objects inside it. Read every one. Remove any the screen does not need.
  A free GUI can carry hidden code, and a LocalScript runs on every player's device.
- Insert with insert_from_creator_store (insert_asset on older builds), into a clearly named
  folder, so it can be found and replaced later.
- Measure the inserted screen with gui-layout's numbers. A Toolbox screen is not checked
  just because it loads. Fix any element that touches another, is off-centre, or sits under
  the top bar.
- If nothing fits, say so and build it from plain Roblox objects. Never invent an asset ID.
- Keep the asset IDs in the plan or in a Config module, not inside a script.
- In the report, list each asset: name, creator, asset ID, what you changed, and where it is.""",
    },
    {
        "name": "gui-verify",
        "use_when": "any screen before it is called done, and any change to an existing screen.",
        "body": """Verify by the numbers first. A picture costs more and proves less than a measurement.
- Use the verifier in references/gui-verify/ (verify_gui.client.lua and gui_rules.lua). Place
  gui_rules.lua as a ModuleScript and verify_gui.client.lua as a LocalScript beside it. Run it in
  Play with a character alive. It prints a PASS or FAIL line per problem and a RESULT line. It
  checks that every element is on screen, siblings keep 8 px gaps and do not overlap, text fits its
  box, and elements marked Centred sit in the middle of their parent (within 1 px).
- Mark deliberate overlaps with the attribute Overhang = true, and centred elements with Centred = true.
  The verifier only checks what is marked, so mark every element that must be centred.
- The verifier fails when it checks nothing. A FAIL with "nothing was checked" means the screen did not load.
- When the verifier cannot run (no Studio, or no play test), write the same checks as numbers in the
  code and say in the report that they were not run.
- Check the centre: compare each centred element's centre to its parent's centre, in pixels.
  Pass only if they match within 1 pixel.
- Check the Check-UI numbers if the style applies: all text is GothamBlack; the canvas is
  #3B5866 with transparency 0; the close button is 38 x 38; the header divider has two tones;
  icons are ScaleType Fit; every interactive element has AnchorPoint (0.5, 0.5); the responsive
  factor is clamped between 0.52 and 1.18; the screen matches one of the five archetypes.
- Check every button path: each button has a click handler, that handler does what the label
  says, and any value it changes is validated on the server (see the server line in check-cycle).
- Check the states: default, hovered, pressed, disabled, loading and empty each exist and look
  different.
- Check that nothing is left behind: a screen that was removed is not still in the tree, and a
  screen that is replaced does not keep its old connections.
- Run the screen once in play, with a character alive, if a human can do it. Otherwise list it
  under "not checked" and name the exact steps the user should run.
- Every check fails when its target is not found. "Not found" is a fail.
Say which checks were run by reading, which by the numbers the code computes, and which need a human.""",
    },
    {
        "name": "project-layout",
        "use_when": "starting a project, adding a system, or deciding where interface code belongs.",
        "body": """- Interface code goes in StarterGui or in a Controller under src/client/. Screen logic that
  does not touch Instances, such as "is this item affordable" or "what text does this show",
  goes in src/shared/Core/ as plain functions.
- The server decides game state. The interface only asks, and shows what the server says.
- Every remote the interface uses is declared in the Net module, with its name in one place.
- Every number a screen uses, such as sizes, colours, prices or timers, comes from a Config module.
- Anything the game must keep has to be in the source files Rojo serves. Rojo removes instances
  in its folders that are not in source on every connect, so a runtime-made screen in those
  folders is lost the next time Studio syncs.""",
    },
    {
        "name": "review-for-exploits",
        "use_when": "any screen that sends a request to the server, shows a price, or handles a Toolbox asset.",
        "body": """Read the screen as an attacker would.
- Can a client send a purchase, reward or setting change the server does not check?
- Can a client send a request too often (no cooldown)?
- Is a price or a success message shown before the server has confirmed it?
- For each Toolbox asset: has every Script and LocalScript inside it been read, and is each one needed?
List what you found, fix it, and say which of these you could not rule out by reading.""",
    },
    {
        "name": "report-what-you-verified",
        "use_when": "the end of every UltraGUI task.",
        "body": """Finish with:
- Screens: each screen, marked done, stuck (with the reason), or not started.
- Style: the Check-UI archetype used, or "plain" if none.
- Pack: the approach chosen and why, with its version and license if it is a library.
- References: each link, file or name the user gave you, and what you took from it.
- Toolbox used: each asset's name, creator, asset ID and what changed, or "none".
- Docs read: each docs address you fetched, and what it confirmed. List any you could not fetch.
- Checked by the numbers: the sizes checked, the three screen sizes, and the results.
- Checked by reading: the check-cycle results, and the cycles each item took.
- Not checked: anything that needs a person to look at the screen in play, a link you could not
  open, an asset ID you could not confirm, or a licence you could not read. Name the play-test steps.
Do not say "tested" or "looks good". Say what was measured, what was read, and what was not run.""",
    },
]


# ============================================================================
#  BUILD AND PRINT
# ============================================================================

EXAMPLE_LUA = HERE / "references" / "gui-syntax" / "example.lua"


def skill_block(skill: dict) -> str:
    body = skill["body"]
    if "<<EXAMPLE>>" in body:
        if not EXAMPLE_LUA.exists():
            sys.exit(f"missing {EXAMPLE_LUA}. Restore references/gui-syntax/example.lua.")
        body = body.replace("<<EXAMPLE>>", EXAMPLE_LUA.read_text(encoding="utf-8").rstrip("\n"))
    return (f"## Skill: {skill['name']}\n"
            f"Use when: {skill['use_when']}\n\n"
            f"{body}")


def full_check_ui_text() -> str:
    if not CHECK_UI_FULL.exists():
        sys.exit(f"missing {CHECK_UI_FULL}. Restore references/check-ui/SKILL.md or drop --full.")
    return CHECK_UI_FULL.read_text(encoding="utf-8")


def full_prompt(with_full: bool = False) -> str:
    parts = [PROMPT] + [skill_block(s) for s in SKILLS]
    if with_full:
        parts.append("## Reference: Check-UI full standard (references/check-ui/SKILL.md)\n\n"
                     + full_check_ui_text())
    return "\n\n".join(parts) + "\n"


def find_skill(name: str) -> dict:
    for s in SKILLS:
        if s["name"] == name:
            return s
    names = ", ".join(s["name"] for s in SKILLS)
    sys.exit(f"no skill named {name!r}. Skills: {names}")


def main() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    ap = argparse.ArgumentParser(description="UltraGUI prompt and skills for ZeroScript.")
    ap.add_argument("--out", help="write the full prompt to this file instead of printing it")
    ap.add_argument("--full", action="store_true", help="add the full Check-UI text to the prompt")
    ap.add_argument("--list", action="store_true", help="list the skill names")
    ap.add_argument("--skill", help="print one skill by name")
    args = ap.parse_args()

    if args.list:
        for s in SKILLS:
            print(f"{s['name']:28} {s['use_when']}")
        return
    if args.skill:
        print(skill_block(find_skill(args.skill)))
        return

    text = full_prompt(with_full=args.full)
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
        print(f"wrote {args.out} ({len(text)} characters)", file=sys.stderr)
    else:
        print(text)


if __name__ == "__main__":
    main()
