local img = Instance.new("ImageButton")
img.Text = "Claim"
img.Font = Enum.Font.GothamBlackX
local f = Instance.new("Frame")
f.Position = UDim2.new(0.5, 0, 0.5)
f.BackgroundColor3 = Color3.fromRGB(1, 2)
f.MouseButton1Click:Connect(function() end)
local w = Instance.new("Wigget")
local g = Instance.new("UIScale")
g.Scale = Enum.ScaleType.Fit
