# LOCAL.md for roblox-texture-gen

Copy this file to `LOCAL.md` and fill it in. `LOCAL.md` is yours and is never shared.

- Studio MCP server name: (which MCP server connects to Roblox Studio, the official Roblox Studio MCP; check with `claude mcp list`)
  Value:
- Texture scratch folder: (where generated PNGs are saved before upload; any folder outside your game project)
  Value:
- Env var name for the optional Pollinations token: `POLLINATIONS_TOKEN` (free registration; raises the rate limit, never paste the value into a file)
  Set in your shell: yes / no
