# LOCAL.md for roblox-animation

Copy this file to `LOCAL.md` and fill it in. `LOCAL.md` is yours and is never shared.

- Path to your R15 rig .blend: (a Blender file with a Rigify-style R15 rig that has FK_* control bones; a free community R15 rig works. Run `calibrate_rig.py` on it first.)
  Value:
- Path to R6 rig .blend (optional): (only if you author R6)
  Value:
- Blender executable: (leave empty if `blender` is on your PATH; otherwise the full path to blender.exe or the Blender binary)
  Value:
- ffmpeg on PATH: (needed for contact sheets and GIFs; check with `ffmpeg -version`)
  Value:
  Value:
- Studio MCP server name: (which MCP server runs `execute_luau` for the Studio builder step; check with `/mcp`)
  Value:
