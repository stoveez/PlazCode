# roblox-sfx local settings (copy to LOCAL.md and fill in)

This skill needs nothing machine-specific: it uses unauthenticated Creator Store endpoints, no API key, and writes to a `work/` folder next to where you run it.

Optional:
- Studio MCP server: which MCP server runs `execute_luau` for you (the built-in Roblox Studio MCP or a third-party one). Value:
