# LOCAL.md for roblox-code

Copy this file to `LOCAL.md` and fill it in. `LOCAL.md` is yours and is never shared.

This skill needs no machine-specific settings. It needs `aftman` (or rojo, wally, selene, stylua and lune individually) on your PATH; `scripts/new_project.py` pins the versions in the scaffold.
