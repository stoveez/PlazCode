PlazCode 1.24.10 — Notion Start Agent, plans and task checklist fixes

Start Agent works again in Notion AI, the AI keeps going after plans, and task checklists show real progress.
