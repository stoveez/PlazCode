PlazCode 1.24.9 — Reliable chats, simpler skills and Blender fixes

More reliable AI chats, simpler skills, complete tool results and a cleaner desktop.
