const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict'),{JSDOM}=require('jsdom');
const source=fs.readFileSync('providers/notion.js','utf8');
for(const placeholder of ['Frag Notion-KI','Ask Notion AI','Demandez à Notion','Pregunta a Notion','Pergunte ao Notion']){
 const dom=new JSDOM('<main><section id="composer"><textarea></textarea><button aria-label="Senden">Send</button></section></main>',{url:'https://app.notion.com/ai',runScripts:'outside-only',pretendToBeVisual:true});
 try{
  const w=dom.window,ed=w.document.querySelector('textarea');ed.placeholder=placeholder;
  w.HTMLElement.prototype.getBoundingClientRect=function(){return{left:100,top:300,width:600,height:50,right:700,bottom:350};};
  vm.runInContext(source+';this.p=RSProvider;',dom.getInternalVMContext());
  assert.equal(w.p.getEditor(),ed,placeholder);assert(w.p.barAnchor(),'Localized AI composer anchors the bar');
 }finally{dom.window.close();}
}
const dom=new JSDOM('<main><textarea placeholder="Frag Notion-KI"></textarea></main>',{url:'https://app.notion.com/p/ordinary-page',runScripts:'outside-only'});
try{vm.runInContext(source+';this.p=RSProvider;',dom.getInternalVMContext());assert.equal(dom.window.p.getEditor(),null,'Ordinary pages remain excluded');}finally{dom.window.close();}
console.log('Localized Notion AI composers are detected and anchored; ordinary page editors remain excluded.');
