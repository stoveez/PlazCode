PlazCode 1.24.3 — Faster desktop, smaller downloads and a better Explorer

Less wasted work, a smaller Windows download and a refreshed workspace.
