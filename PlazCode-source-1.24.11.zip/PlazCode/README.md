PlazCode 1.24.11 — Notion startup send fix

Fixes Notion startup getting stuck with a half-written command list in the chat box, which then left every command as not run.
