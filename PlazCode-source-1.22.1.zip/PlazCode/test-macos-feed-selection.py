from pathlib import Path
import tempfile,subprocess,json
original=Path(__file__).with_name('Configure-MacOS-Updates.command').read_text()
with tempfile.TemporaryDirectory(prefix='plazcode-mac-feed-') as folder:
 root=Path(folder);plutil=root/'plutil.py'
 plutil.write_text('''import json,sys
from pathlib import Path
args=sys.argv[1:];p=Path(args[-1])
try:
 value=json.loads(p.read_text())
 if args[0]=='-extract':print(value[args[1]])
 elif args[0]=='-replace':value[args[1]]=args[3];p.write_text(json.dumps(value))
 else:raise ValueError('Unknown plutil action')
except Exception:sys.exit(1)
''')
 script=root/'Configure-MacOS-Updates.command';script.write_text(original.replace('/usr/bin/plutil','python3 '+str(plutil)))
 source=root/'update-source.json';shared='https://raw.githubusercontent.com/stoveez/PlazCode/main/latest.json';mac=shared.replace('latest.json','latest-macos.json')
 for payload,expected in [(None,mac),({'feedUrl':'https://raw.githubusercontent.com/stoveez/PlazCodeneww/main/latest.json','other':'keep'},mac),({'feedUrl':'https://raw.githubusercontent.com/stoveez/PlazCodeneww/main/latest-macos.json','other':'keep'},mac),({'feedUrl':shared,'other':'keep'},mac),({'feedUrl':'','other':'keep'},mac),({'feedUrl':'https://custom.example/feed','other':'keep'},'https://custom.example/feed'),({'feedUrl':mac,'other':'keep'},mac)]:
  if source.exists():source.unlink()
  if payload is not None:source.write_text(json.dumps(payload))
  result=subprocess.run(['bash',str(script)],capture_output=True,text=True,check=True)
  data=json.loads(source.read_text());assert data['feedUrl']==expected
  if payload is not None:assert data['other']=='keep'
  assert not list(root.glob('.mac-update-source.*'))
 for malformed in ['not json','{"other":"keep"}']:
  source.write_text(malformed);subprocess.run(['bash',str(script)],capture_output=True,text=True,check=True);assert source.read_text()==malformed
 for name in ['MacOS_Setup.command','Start-PlazCode.command','Update-PlazCode.command']:
  assert '/bin/bash "$root/Configure-MacOS-Updates.command"' in Path(__file__).with_name(name).read_text()
 print('PASS Mac feed migration with simulated plutil: fresh/default/empty/custom/corrupt sources, unrelated settings and atomic cleanup.')
