from pathlib import Path
import re
source=Path('Update-PlazCode.ps1').read_text()
names=set(re.findall(r"'([^']+)'",re.search(r'\$preservedNames = @\((.*?)\)',source).group(1)))
pattern=re.search(r"\$preservedFolders = '([^']+)'",source).group(1)
for path in ['config.json','config.local.json','plazcode-settings.json','bridge-pairing.json','memory.json','checkpoints.json','catalog.json','update-source.json',r'templates\index.json',r'PlazCode.exe.WebView2\Default\settings','templates/index.json','logs/log.txt','backups/PlazCode.exe','runtimes/node.exe','PlazCode.exe.WebView2/Default/Local Storage/setting']:
 assert Path(path).name in names or re.search(pattern,path,re.I),path
for path in ['PlazCode.exe','core/main.js','manifest.json','Update-PlazCode.ps1']:
 assert Path(path).name not in names and not re.search(pattern,path,re.I),path
assert '$_.Name -notin $preservedNames -and $relative -notmatch $preservedFolders' in source
print('Updater selection fixture protects settings, MCP configuration, memory, pairing, templates, caches and WebView data while selecting update files.')
