#!/bin/bash
set -euo pipefail
root=$(cd -- "$(dirname -- "$0")" && pwd)
[[ -f "$root/PlazCode.app/Contents/MacOS/PlazCode" ]] || { echo 'PlazCode.app is missing. Extract the complete release ZIP.' >&2;exit 1; }
/bin/chmod 755 "$root/PlazCode.app/Contents/MacOS/PlazCode" "$root/Start-PlazCode.command" "$root/Update-PlazCode.command"
echo 'Load PlazCode-Extension in Chrome or Edge using Load unpacked. Enable Studio as MCP server in Roblox Studio Assistant settings.'
# Clear the download quarantine so macOS runs PlazCode.app from this folder
# instead of a temporary read-only copy, and remember this folder for updates.
/usr/bin/xattr -dr com.apple.quarantine "$root" 2>/dev/null || true
config="$HOME/Library/Application Support/PlazCode"
/bin/mkdir -p "$config" && printf '%s\n' "$root" > "$config/install-root.pending" && /bin/mv "$config/install-root.pending" "$config/install-root" || true
/bin/bash "$root/Configure-MacOS-Updates.command"
exec /usr/bin/open "$root/PlazCode.app"
